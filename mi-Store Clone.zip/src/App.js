import './App.css';
import PreNavbar from './components/PreNavbar';
import Navbar from './components/Navbar.js';
import { BrowserRouter as Router, Route } from 'react-router-dom/cjs/react-router-dom.min.js';
import Slider from './components/Slider.js';
import data from './data/data.js';
import Offers from './components/Offers.js';
import Heading from "./components/Heading.js";
import StarProduct from "./components/StarProduct.js";
import HotAccessoriesMenu from "./components/HotAccessoriesMenu.js";
import HotAccessories from "./components/HotAccessories.js";
import ProductReviews from "./components/ProductReviews.js";
import Videos from "./components/Videos.js";
import Banner from "./components/Banner.js";
import Footer from "./components/Footer.js";



function App() {
  return (
    <Router>
      <PreNavbar />
      <Navbar />
      
      <Slider start={data.banner.start}/>
      <Offers offers={data.offer}/>
      <Heading text="STAR PRODUCTS" />
      <StarProduct starProduct={data.starProduct}/>
      <Heading text="HOT ACCESSORIES" />
      <HotAccessoriesMenu />

      <Route exact path="/music">
        <HotAccessories music={data.hotAccessories.music} musicCover={data.hotAccessoriesCover.music} />
      </Route> 

      <Route exact path="/smartDevice">
        <HotAccessories smartDevice={data.hotAccessories.smartDevice} smartDeviceCover={data.hotAccessoriesCover.smartDevice} />
      </Route> 
      
      <Route exact path="/home">
        <HotAccessories home={data.hotAccessories.home} homeCover={data.hotAccessoriesCover.home} />
      </Route> 
      
      <Route exact path="/lifestyle">
        <HotAccessories lifestyle={data.hotAccessories.lifeStyle} lifestyleCover={data.hotAccessoriesCover.lifeStyle} />
      </Route> 
      
      <Route exact path="/mobileAccessories">
        <HotAccessories mobileAccessories={data.hotAccessories.mobileAccessories} mobileAccessoriesCover={data.hotAccessoriesCover.mobileAccessories} />
      </Route> 

      <Heading text="PRODUCT REVIEWS" />
      <ProductReviews   productReviews= {data.productReviews} />

      <Heading text = "Videos" />
      <Videos  videos={data.videos} />

      <Heading text = "IN THE PRESS" />

      <Banner banner = {data.banner} />
      <Footer footer = {data.footer}/>


    </Router>
  );
}

export default App;
